# Alignment-rate campaign 20260909_205843

Coils A and C are cut mid-run; the rotor's spin axis swings and the rate of that
swing is measured. 11 drive frequencies, 10-120 Hz, 4-22 repeats each.

## What the rate is

The gradient of the FIRST steep ramp after the cut, extrapolated back to the cut
(`relu_window`). Not a rise time, and not a 10-90% band. A spinning axis precesses
rather than falls, and the precession rate

    Omega_prec = kappa_t / (I_s * omega)

is independent of how far off-axis the rotor is, so a straight line is the correct
model of the ramp and its slope is a physical parameter. The 10-90% band under-reads
badly enough to carry an assert in `alignment_rate._self_check`. Derivation:
`controller/control/theory.md` 11.1-11.3.

Rise time would be worse than mis-specified here: the rise-peak-fall structure in
every trace is a 2-4 Hz MECHANICAL mode (f = 3.86 - 0.0155*f_drive, most likely the
8 mm takeoff rod), not the alignment dynamics. See theory.md 24.10.

## data/

    sweep_index.csv     every take in the campaign: freq, repeat, outcome, paths, heat
    NNNhz_index.csv     per-frequency take index
    campaign.csv        per-frequency aggregate; `rate_relu_med` is the headline rate
    transients.csv      pooled transient per frequency
    summary.csv         per-take summary

Takes referenced by absolute path in the index files are NOT bundled (video and
axis.csv live under results/flights/). This package holds the derived tables.

## figures/

    trial_fits.png      alignment fit on one representative trial per frequency
    trials_NNNhz.png    EVERY repeat at one frequency, alignment fit drawn
    rate_fits.png       pooled angle with the rate fits drawn
    rate_scatter.png    swing and rate vs drive frequency, every repeat
    rate_vs_frequency.png, transients.png, coupling.png

## scripts/

`alignment_rate.py` is the analysis; run its `__main__` for self-checks. The others
are what it imports or what produced the takes (`tilt_sweep.py` runs the campaign).
Flat layout here for portability -- in the repo these are `controller/control/` and
`controller/pose/`, and the module imports by full package path.

## Reading the result

The rate is NOT monotonic in drive frequency, and should not be: omega sits in the
DENOMINATOR of Omega_prec. Below resonance the coil is capacitive, so B rises
linearly with f and B/f is flat -- which is what 20-80 Hz shows (~870-1200 deg/s).
The roll-off above 90 Hz is either passing resonance or losing lock; the amplitude
sweep at fixed frequency separates them.

CAVEAT: rotor spin rate is ASSUMED equal to drive frequency throughout
(`spin_hz=freq_hz`, alignment_rate.py:1000 and :1322). It is never measured. Every
1/omega above rests on that.
