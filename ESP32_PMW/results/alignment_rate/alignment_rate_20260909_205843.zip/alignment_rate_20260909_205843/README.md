# Alignment-rate campaign report — 2026-09-09/10

How fast the robot re-orients after coils A and C are cut, against drive frequency.
Every file here is regenerated from the takes; nothing in this directory is a capture.

All commands run from the repo root, against `results/alignment_rate/20260909_205843`.

| file | made by |
|---|---|
| `campaign.csv` | `alignment_rate.py --campaign <root>` — the authoritative per-frequency table |
| `rate_vs_frequency.png` | same command |
| `transients.png` | same command |
| `rate_scatter.png` | `alignment_rate.py --scatter <root>` — swing and rate, every repeat |
| `trial_fits.png` | `alignment_rate.py --trials <root>` — one median-rate trial per frequency |
| `trials_0NNhz.png` | `alignment_rate.py --trials <root> --only-hz NN` — EVERY repeat at that frequency |
| `coupling.png` | `coupling.py <root>` — radial/azimuth shared lines and what deprojecting them does |

## Stale — do not read

`summary.csv` and `transients.csv` are dated 2026-09-09 21:18 and were written by
`alignment_rate.py <take>` (the single-take path) before the campaign existed. They predate
the 2026-09-10 rewrite of the rate metric and disagree with `campaign.csv` on every number.
Kept only because nothing in `results/` is deleted. **`campaign.csv` is the current table.**

## What the rate means, as of 2026-09-10

The metric is the gradient of the response's rising edge: find the first swing that reaches
70% of the record's height, walk back to the foot of that rise, trim `BUFFER_FRAC` off each
end and fit the middle. Dead time is where that fitted line, run backwards, crosses the level
the trace held before it. See `alignment_rate.relu_window` for why each of those is what it
is — every clause in it is a failure that was found in these takes and fixed.

The angle plotted is the **separation between the robot's lean direction now and its
pre-cut lean direction**, an `arccos` of two unit vectors. It is in [0, 180] and never
negative; there is no unwrap and no branch anywhere in it, so it cannot flip sign.

## Trials that are refused, and why

A repeat reports no rate when the record cannot support one. These are flight conditions,
not analysis failures, and they are worth reading before deciding what to re-run:

* the fitted ramp's onset extrapolates to before the cut — the rise was already underway
  when the coils dropped, so it is not the response to them (e.g. 50 Hz `2026-09-09_234425`)
* the trace falls below its pre-cut level within 0.4 s of the cut — the pre-cut window was
  not a settled reference (e.g. 10 Hz `2026-09-09_210122`)
* the pre-cut lean is below 5 deg, so there is no lean DIRECTION to measure a change of
  (60 Hz `2026-09-10_000732`: median pre-cut lean 2.9 deg, 3 of 206 samples usable)
* the robot was already swinging hard at the cut (60 Hz `2026-09-09_212930`: 12.7 deg of
  scatter on the *smoothed* pre-cut trace)

## Known caveats

* **40 Hz mixes two hold times.** Reps 11-14 (`073235`-`073606`) flew the 0.5 s frequency
  hold; reps 15-19 (`073823`-`074326`) flew the original. Not like-for-like.
* **60 Hz is bimodal**: five repeats at 968-1600 deg/s with 39-89 ms of dead time, two at
  ~500 deg/s with 145-190 ms. Which is typical is not yet established.
* **70 Hz has 2 usable repeats.** Any number quoted from it is a pair, not a statistic.
* Takes solved below twice their drive frequency are refused outright and listed by the
  `--campaign` run; the once-per-rev wobble aliases below that.
