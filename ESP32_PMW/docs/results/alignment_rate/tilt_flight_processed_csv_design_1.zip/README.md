# Alignment-rate campaigns: processed CSVs

Design 1 (`results/alignment_rate/20260909_205843`, 117 takes) and design B, the half outer
ring (`results/alignment_rate/20260910_droneB`, 0 takes). Made by
`controller/control/package_takes.py`.

## takes/design_<d>/tilt_flight_design_<d>_<freq>hz_<repeat>.csv

One file per good take; `<repeat>` is the campaign index's own repeat number. One row per frame.

| column | meaning |
|---|---|
| frame | video frame index, shared by all columns in the row |
| t_s | host capture time, s (monotonic clock, same as the sweep.log stamps) |
| t_from_cut_s | seconds from the cut (coils A and C off; the take's `KILL_` label) |
| phase | ramp, settle, hold, drop (after the cut), spindown, off -- from the sweep.log labels |
| rotor_stopped | 1 once the rotor has stopped (`alignment_rate.spin_stop`); axis columns are meaningless after that |
| nx ny nz | fused 3-D rotor axis, unit vector, world frame (camera A's axis is +z, NOT up) |
| agree_deg | angle between the axes from camera A and camera B |
| minor_nx minor_ny minor_nz | the minor-axis (two-plane intersection) axis estimate |
| minor_vs_conic_deg | its angle to the conic-backprojection estimate |
| x_mm y_mm z_mm | triangulated disc centre, mm, world frame |
| radius_mm | disc radius from the unforeshortened major axis, mm |
| a_* / b_* | camera A / B ellipse fit: theta_deg (axis-ratio tilt), area_px, cx cy (centre, px), d1 d2 (axis lengths, px), ang_deg |

A blank cell means that output had no solution for that frame -- EXCEPT where the source file
does not exist for that take at all; `manifest.csv` says which.

## What exists per design

| | design 1 | design B |
|---|---|---|
| takes here | 117 | 0 |
| fused axis + minor axis (`nx..`, `minor_*`, `x_mm..`) | all | all |
| per-camera fits (`a_*`, `b_*`) | 0 of 117 | 0 of 0 |
| video beside the take | 0 of 117 | 0 of 0 |

Design 1's takes were stripped after solving: their `A/A.mp4`, `B/B.mp4` and `frames.csv` live
in `results/flights/Archive.zip`, and `tilt_A.csv` / `tilt_B.csv` were never kept, so its files
carry no per-camera columns. Re-solving those takes from the archive would produce them.
Design B's video is on the USB stick (`/Volumes/UBUNTU 24_0/ESP32_PMW_flights/droneB/`), which
`manifest.csv` records per take in `video_dir`.

## manifest.csv

One row per take file: design, freq_hz, repeat, take stamp, where its video and log live,
the cut time on the host clock, when the rotor stopped (blank = never within the take), and
the take's own results -- rate_relu_deg_s, swing_amp_deg and modal_repeat from the rate
analysis; settle_swing_deg, settle_10pct_s and settle_note from the settling analysis.
`per_view_columns` and `video_present` say whether that take's per-camera fits and video are
on disk, so a blank column can be told from a missing source.

## summary/

Each campaign's result tables (campaign, campaign_trials, settling, settling_by_freq) and the
design comparison's statistics and pooled traces. Their provenance and caveats are in
`results/alignment_rate/compare_1_vs_B/README.md` and `controller/control/theory.md` 24.12-24.13.
